﻿using System;

namespace My_Project4
{
    class MyProject4
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Number for which you need an inverted triangle: ");
            int a= Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter a width for your inverted triangle: ");
            int b= Convert.ToInt32(Console.ReadLine());

            //Inverted right angle triangle
            for (int i = b; i >= 1; i--)// i is the number of rows
            {
                for (int j = 1; j <= i; j++) // j is the number of columns
                {
                    Console.Write(a);
                }

                Console.WriteLine();
            }
            //Right angle triangle
            for (int i = 1; i <= b; i++)// i is the number of rows
            {
                for (int j = 1; j <= i; j++) // j is the number of columns
                {
                    Console.Write(a);
                }

                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
