using System;

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Number for which you need an inverted triangle: ");
            int a= Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter a width for your inverted triangle: ");
            int b= Convert.ToInt32(Console.ReadLine());
            for (int row = b; row >= 1; --row)
            {
                for (int col = 1; col <= row; ++col)
                {
                    Console.Write(a);
                }

                Console.WriteLine();
            }

        }
    }