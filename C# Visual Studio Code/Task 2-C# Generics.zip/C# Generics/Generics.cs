﻿using System;
namespace Generics
{
    public class Myclass<T>
    {
        public bool campare(T a, T b)//(int a,int b)
        {
            if(a.Equals(b))//(a==b)
            {
                return true;
            }
            else
            {
                return false;
                
            }
        }
    }
    class Program
    {
        static void Main(string[]args)
        {
            Myclass <int>check=new Myclass<int>();
            bool res=check.campare(8,8);//(a,b)
            Console.WriteLine(res);
            // Console.Readkey();
        }
    }
}