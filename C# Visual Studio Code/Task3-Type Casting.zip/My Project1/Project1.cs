﻿using System;
using System.Console;

namespace Program1
{
    class Program1
    {
        static void Main(string[] args)
        {
            double a;
            int b;
            // getting Input of a & b
            Console.WriteLine("Enter a double number:"+" ");
            a=Convert.ToDouble(Console.ReadLine());
            b=Convert.ToInt32(Console.ReadLine());
            // getting output in Double and Int data type
            Console.WriteLine("a:"+" "+Convert.ToDouble(a));
            Console.WriteLine("b:"+" "+Convert.ToInt32(a));

        
        }
    }
}