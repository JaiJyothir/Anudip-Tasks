using  System;

class multidArrayDemo 
{
	static void Main(string[] args)
    {
        int[,]arr =new int [5,6];
	    int a=0;
        for (int i =0;i<arr.GetLength(0);i++) 
        {
            for (int j=0; j<arr.GetLength(1); j++) 
            {
                arr[i,j]=a;
                a+=5;
            }
        }
	for (int i=0;i<arr.GetLength(0);i++) 
    {
		for (int j=0;j<arr.GetLength(1); j++) {
			Console.WriteLine(arr[i,j]+" ");
			Console.WriteLine();
		}
	}
    }
}