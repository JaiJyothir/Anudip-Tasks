using System;
using static System.Console;
using static System.Math;

namespace ProgramBasics
{
    class getnumbers
    {
        public int Calculation(int num1,int num2)
        {
            return num1*num2;
                
        }
    }
    class ProgramBasics
    {
        static void Main(string[] args)
        {
            // Print a string Hello world
            WriteLine("Hello World!");
            //Adding two integers
            int num,num1,num2;
            num1=25;
            num2=10;
            num=num1+num2;
            WriteLine(num);
            //printing two strings
            string firstname="Jai";
            string lastname="Jyothir";
            string fullname=firstname+" "+lastname;
            WriteLine(fullname);
            //using a math operator to find the square root of a number
            double n  = Sqrt(9);
            WriteLine("Square root of 9 is " + n);
            //get value from the class getnumbers and perform multiplication operation
            getnumbers myclass=new getnumbers();
            WriteLine("The product of 2 numbers is:"+" "+myclass.Calculation(10,8));

        }
    }
}
