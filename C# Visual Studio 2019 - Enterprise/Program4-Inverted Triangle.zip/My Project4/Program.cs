﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_Project4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a,b;
            Console.Write("Enter a Number for which you need an inverted triangle: ");
            Console.ReadLine(a);
            Console.Write("Enter a width for your inverted triangle: ");
            Console.ReadLine(b);
            
            for(int i=b;i<a+1;i++)

        }
    }
}
