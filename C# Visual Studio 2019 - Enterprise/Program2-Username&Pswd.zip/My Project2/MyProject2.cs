﻿using System;

namespace MyProject2
{
    class Input
    {
        string username, password, userid, userpwd;
        public void Inp()
        {
            Console.Write("Enter a Username:" + " ");
            username = Console.ReadLine();
            Console.Write("Enter a Password:" + " ");
            password = Console.ReadLine();
            Console.Clear();
        }
        public void Check()
        {
            int i;
            for (i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter your UserID");
                userid = Console.ReadLine();
                Console.WriteLine("Enter your Password");
                userpwd = Console.ReadLine();
                Console.Clear();
                if (username == userid && password == userpwd)
                {
                    Console.WriteLine("Welcome" + " " + username);
                    break;
                }

                else if (i == 2)
                {
                    Console.WriteLine("You are not a valid user");
                }
                else if (i < 2)
                {
                    Console.WriteLine("please enter a valid UserId & pasword combination");
                }
            }
        }
        public class All
        {
            static void Main()
            {
                Console.WriteLine("-------------------------------");
                Console.WriteLine("  "+"Create a New Account");
                Console.WriteLine("-------------------------------");
                //string username = Console.ReadLine();
                Input myObj = new Input();
                myObj.Inp();
                myObj.Check();
                Console.ReadKey();
            }
        }


    }
}
